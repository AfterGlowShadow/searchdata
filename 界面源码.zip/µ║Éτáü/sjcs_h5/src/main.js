// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
//引入vant
import Vant from 'vant';
import 'vant/lib/index.css';

Vue.use(Vant);
//
//引入axios
import axios from 'axios'
import qs from 'qs'

axios.defaults.baseURL = process.env.BASEURL
Vue.prototype.$url = 'http://www.norhoraftersales.com'
//挂载axios
Vue.prototype.$axios = axios
Vue.prototype.$qs = qs
//
Vue.config.productionTip = false
/* eslint-disable no-new */
//导航守卫
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requiresAuth)) {
    //这里判断用户是否登录，验证本地存储是否有token
    if (!localStorage.getItem('token')) { // 判断当前的token是否存在
      next({
        path: '/login',
        query: {redirect: to.fullPath}
      })
    } else {
      next()
    }
  } else {
    next() // 确保一定要调用 next()
  }

})
new Vue({
  el: '#app',
  router,
  components: {App},
  template: '<App/>'
})
