<template>
  <div class="index">
    <!--navbar-->
    <div class="index_navbar">
      <!--左侧-->
      <div class="navbar_left">
        <span> <img src="../../../../static/img/seach_icon.png" alt="">家具数据查询网站</span>
      </div>
      <!--右侧-->
      <div class="navbar_right">
        <span>{{name}}</span>
        <span @click="logOut"> <img src="../../../../static/img/exit.png" alt=""></span>
      </div>
    </div>
    <!--公告栏-->
    <div class="index_bulletin">
      <!--公告标题-->
      <div class="bulletin_tit">
        <span>公告栏</span>
      </div>
      <!--公告内容-->
      <div class="bulletin_text">
        <span>{{announcement.data}}</span>
      </div>
    </div>
    <!--数据列表-->
    <div class="list_content" v-if="type == 1">
      <!--搜索框-->
      <div class="list_seach">
        <input type="text" placeholder="搜索条形码/网店名称/厂家货号/供应商" v-model="sea">
        <span @click="addseache">搜索</span>
      </div>
      <!--商品列表循环大包围-->
      <div class="index_goods_cycle">
        <!--循环体-->
        <div class="goods_cycle_content" v-for="(item,index) in list" :key="index" @click="checkDetails(item)">
          <!--图片-->
          <div class="cycle_img">
            <img :src="$url+item.goods_pic" alt="">
          </div>
          <!--内容右侧-->
          <div class="cycle_right">
            <!--第一条-->
            <div class="right_1">
              <span>条形码：<b>{{item.bar_code}}</b></span>
              <span style="margin-left: .5rem">网店名称：<b>{{item.shop_name}}</b></span>
            </div>
            <!--后面几条-->
            <span>厂家货号：<b>{{item.goods_number}}</b></span>
            <span>供应商：<b>{{item.supplier}}</b></span>
          </div>
        </div>
        <!--分页器-->
        <div class="index_goods_fen">
          <van-pagination
            v-model="currentPage"
            :page-count="pages"
            mode="simple"
            @change="handpagination"
          />
        </div>
      </div>
    </div>
    <!--数据详情-->
    <div class="list_details" v-if="type == 2">
      <div class="details_content">
        <!--图片和商品基本信息-->
        <div class="details_basic">
          <img :src="$url+details.goods_pic" alt="" @click="getimg(details.goods_pic)">
          <div class="basic_right">
            <span>条形码：{{details.bar_code}}</span>
            <span>网店名称：{{details.shop_name}}</span>
            <span>厂家货号：{{details.goods_number}}</span>
            <span>供应商：{{details.supplier}}</span>
          </div>
        </div>
        <!--中部基本信息-->
        <div class="details_middle">
          <span>最后问题批次到货日期：{{details.arrival_date}}  </span>
          <span>客诉首次反馈日期：{{details.feedback_date}}</span>
          <span>客户ID（多个排序按反馈时间由早及晚:</span>
          <span>{{details.customer_id}}</span>
        </div>
        <!--客诉问题点-->
        <div class="details_customer">
          <span>客诉问题点</span>
          <div class="customer">
            <span>{{details.question}}</span>
          </div>
        </div>
        <!--问题点分析-->
        <div class="details_customer">
          <span>问题点分析</span>
          <div class="customer">
            <span>{{details.question_analysis}}</span>
          </div>
        </div>
        <!--问题点处理方案-->
        <div class="details_customer">
          <span>问题点处理方案</span>
          <div class="customer">
            <span>{{details.question_solutions}}</span>
          </div>
        </div>
        <!--问题图片-->
        <div class="details_img">
          <span>问题图片</span>
          <div class="img_img">
            <img :src="$url+details.question_pic1" alt="" @click="getimg(details.question_pic1)">
            <img :src="$url+details.question_pic2" alt="" @click="getimg(details.question_pic2)">
            <img :src="$url+details.question_pic3" alt="" @click="getimg(details.question_pic3)">
            <img :src="$url+details.question_pic4" alt="" @click="getimg(details.question_pic4)">
          </div>
        </div>
        <!--详情视频-->
        <div class="details_mp4">
          <span>详情视频</span>
          <div class="mp4_content">
            <span v-if="details.video == ''">暂无视频</span>
            <video width="100%" height="100%" controls>
              <source :src="$url+details.video" type="video/mp4">
            </video>
          </div>
        </div>
        <!--备注-->
        <div class="details_note">
          <span>备注</span>
          <div class="note_content">
            <span
              style="font-size: 1.5rem;margin-top: .5rem"
              v-if="details.remark1 == null && details.remark2 == null && details.remark3 == null && details.remark4 == null"
            >暂无备注</span>
            <span>{{details.remark1}}</span>
            <span>{{details.remark2}}</span>
            <span>{{details.remark3}}</span>
            <span>{{details.remark4}}</span>
          </div>
        </div>
        <!---->
      </div>
    </div>
    <!--返回按钮-->
    <div class="btnBack" @click="goback" v-if="type == 2">
      <img src="../../../../static/img/goback.png" alt="">
    </div>
    <!--脚步-->
    <div class="fotterrr">
      <span>Copyright ©2019     浙ICP备123456789号-1    浙公网安备</span>
    </div>
  </div>
</template>
<script>
    import {ImagePreview} from 'vant';

    export default {
        name: "index",
        data() {
            return {
                name: localStorage.getItem('name'),
                announcement: [], //公告栏数据接收
                list: [], // 数据列表接收
                details: [], // 数据详情接收
                page: 1, // 分页器
                pages: '', // 分页器计算
                currentPage: 1, // 分页器组件当前页码
                type: 1, //列表与详情切换参数
                sea: '', // 搜索框
            }
        },
        created() {
            this.bullentBoard()
            this.getlist()
        },
        watch: {
            sea(val, oldval) {
                if (val == '') {
                    this.getlist()
                }
            }
        },
        methods: {
            //数据列表
            getlist() {
                let params = {
                    page: this.page,
                    list_rows: 8,
                }
                this.$axios.post('/api/home/data/datagetalllist', this.$qs.stringify(params), {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                }).then(res => {
                    this.pages = Math.ceil(res.data.data.total / res.data.data.listRows)
                    this.list = res.data.data.data
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },
            //搜索
            addseache() {
                let params = {
                    page: this.page,
                    list_rows: 8,
                    search: this.sea,
                }
                this.$axios.post('/api/home/data/datalistlike', params, {}).then(res => {
                    this.list = res.data.data.data
                    this.pages = Math.ceil(res.data.data.total / res.data.data.listRows)
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },
            //点击查看详情
            checkDetails(item) {
                this.details = item
                console.log(this.details);
                this.type = 2
            },
            //点击放大商品主图
            getimg(goods_pic) {
                ImagePreview({
                    images: [this.$url + goods_pic],
                });
            },
            //问题图片点击放大
            getimg(question_pic1) {
                ImagePreview({
                    images: [this.$url + question_pic1],
                });
            },
            getimg(question_pic2) {
                ImagePreview({
                    images: [this.$url + question_pic2],
                });
            },
            getimg(question_pic3) {
                ImagePreview({
                    images: [this.$url + question_pic3],
                });
            },
            getimg(question_pic4) {
                ImagePreview({
                    images: [this.$url + question_pic4],
                });
            },
            //返回详情
            goback() {
                this.type = 1
                this.details = []
            },
            //退出登录
            logOut() {
                localStorage.removeItem('token')
                this.$router.push({name: 'login'})
            },
            //分页器改变
            handpagination() {
                this.page = this.currentPage
                this.getlist()
            },
            //公告栏数据
            bullentBoard() {
                let params = {}
                this.$axios.post('/api/home/daohang', {}, {}).then(res => {
                    this.announcement = res.data
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },

        }
    }
</script>
<style scoped lang="scss">
  .index {
    width: 100%;
    height: 100%;
    position: fixed;
    background-image: url(../../../../static/img/bgc.jpeg);
    background-size: 100% 100%;
    background-repeat: no-repeat;
    overflow: scroll;
  }

  /*公告栏*/
  .index_bulletin {
    width: 100%;
    height: 11rem;
    background: rgba(255, 255, 255, .1);
    margin-top: 5.5rem;
    /*公告标题*/
    .bulletin_tit {
      text-align: center;
      padding-top: 1.8rem;

      span {
        font-size: 2rem;
        color: #ffffff;
      }
    }

    /*  内容*/
    .bulletin_text {
      height: 7rem;
      text-indent: 2rem;
      overflow: scroll;

      span {
        font-size: 1.5rem;
        color: #ffffff;
      }
    }
  }

  /*数据列表*/
  .list_content {
    width: 95%;
    background-color: #fff;
    margin: 0 auto;
    /*搜索框*/
    .list_seach {
      width: 95%;
      margin: 0 auto;
      display: flex;
      align-items: center;
      margin-top: .5rem;
      padding-top: .5rem;

      input {
        width: 80%;
        height: 3.75rem;
        border: none;
        outline: none;
        background-color: #F0F2F4;

        &::-webkit-input-placeholder {
          color: #999999;
          font-size: 1.5rem;
          padding-left: .5rem;
        }
      }

      span {
        width: 20%;
        height: 3.75rem;
        display: inline-block;
        background-color: #08213A;
        color: #fff;
        text-align: center;
        line-height: 3.75rem;
        font-size: 2rem;
      }
    }

    /*循环体大包围*/
    .index_goods_cycle {
      width: 95%;
      margin: .5rem auto;
      /*循环体*/
      .goods_cycle_content {
        width: 100%;
        display: flex;
        border-bottom: 1px solid #999999;
        padding-bottom: .5rem;
        margin-top: 1rem;
        /*图片*/
        .cycle_img {
          img {
            width: 7.5rem;
            height: 7.5rem;
          }
        }

        /*循环体右侧*/
        .cycle_right {
          width: 100%;
          height: 7.5rem;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          font-size: 1.625rem;
          margin-left: 1rem;

          span {
            color: #666666;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
          }

          /*第一条*/
          .right_1 {
            display: flex;
          }
        }
      }

      /*分页器*/
      .index_goods_fen {
        padding-top: .5rem;
        padding-bottom: .5rem;
      }
    }
  }

  /*数据详情*/
  .list_details {
    width: 95%;
    background-color: #fff;
    margin: 0 auto;
    /*容器包围*/
    .details_content {
      width: 95%;
      margin: .5rem auto;
      padding-top: .5rem;
      padding-bottom: .5rem;
      /*上部基本信息*/
      .details_basic {
        width: 100%;
        display: flex;

        img {
          width: 13.75rem;
          height: 13.75rem;
        }

        /*图片右侧*/
        .basic_right {
          width: 100%;
          height: 13.75rem;
          display: flex;
          flex-direction: column;
          word-break: break-all;
          justify-content: space-between;
          margin-left: .5rem;

          span {
            font-size: 1.625rem;
            color: #666666;
          }
        }
      }

      /*中部基本信息*/
      .details_middle {
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-top: 1rem;

        span {
          font-size: 1.625rem;
          color: #666666;
        }
      }

      /*客诉问题点*/
      .details_customer {
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-top: .5rem;

        span {
          font-size: 1.625rem;
          color: #333333;
          margin-bottom: .5rem;
        }

        .customer {
          width: 100%;
          height: 10rem;
          margin: 0 auto;
          background-color: #DDDDDD;
          border: .1rem solid rgba(221, 221, 221, 1);
          text-align: center;
          overflow: scroll;

          span {
            display: inline-block;
            width: 95%;
          }
        }
      }

      /*问题图片*/
      .details_img {
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-top: .5rem;

        span {
          font-size: 1.625rem;
          color: #333333;
          margin-bottom: .5rem;
        }

        .img_img {
          img {
            width: 10rem;
            height: 10rem;
          }
        }
      }

      /*详情视频*/
      .details_mp4 {
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-top: .5rem;

        span {
          font-size: 1.625rem;
          color: #333333;
          margin-bottom: .5rem;

        }

        .mp4_content {
          width: 100%;
          height: 10rem;
          background-color: #DDDDDD;
        }
      }

      /*备注*/
      .details_note {
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-top: .5rem;

        span {
          font-size: 1.625rem;
          color: #333333;
          margin-bottom: .5rem;

        }

        .note_content {
          width: 100%;
          height: 10rem;
          background-color: #DDDDDD;
          display: flex;
          flex-direction: column;
          overflow: scroll;
          text-align: center;

          span {
            display: inline-block;
            width: 95%;
            margin: 0 auto;
          }
        }
      }
    }
  }

  /*返回按钮*/
  .btnBack {
    position: fixed;
    left: 1.5rem;
    bottom: 3rem;
    z-index: 999;

    img {
      width: 3rem;
      height: 3rem;
    }
  }

  /*脚步*/
  .fotterrr {
    width: 100%;
    height: 7rem;
    display: flex;
    align-items: center;
    justify-content: center;

    span {
      font-size: 1.5rem;
      color: #ffffff;
    }
  }

  /*navbar*/
  .index_navbar {
    width: 100%;
    height: 5.5rem;
    background-color: #000000;
    position: fixed;
    top: 0;
    display: flex;
    align-items: center;
    /*左侧内容*/
    .navbar_left {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      margin-left: .5rem;

      span {
        display: flex;
        align-items: center;
        color: #ffffff;
        font-size: 1.875rem;

        img {
          width: 1.8rem;
          height: 1.8rem;

        }
      }
    }

    /*右侧内容*/
    .navbar_right {
      width: 100%;
      height: 5.5rem;
      display: flex;
      align-items: center;
      justify-content: flex-end;

      span {
        display: flex;
        align-items: center;

        &:nth-child(1) {
          color: #ffffff;
          font-size: 1.8rem;
          border-right: 1px solid #ffffff;
          padding-right: 1rem;
        }

        &:nth-child(2) {
          margin-left: 1rem;
          margin-right: 1rem;

          img {
            width: 1.8rem;
            height: 1.8rem;
          }
        }
      }
    }
  }
</style>
