<template>
  <div class="login">
    <!--登录-->
    <div class="login_tit">
      <span>登录</span>
    </div>
    <!--登录提交-->
    <div class="login_sub">
      <form action="">
        <div class="sub_item">
          <input type="text" placeholder="请输入登录账号" v-model="name">
        </div>
        <div class="sub_item">
          <input type="password" placeholder="请输入登录密码" v-model="pwd">
        </div>
      </form>
    </div>
    <!--立即登录-->
    <div class="submit">
      <input type="button" value="立即登录" @click="loginsub">
    </div>
  </div>
</template>
<script>
  export default {
    name: "login",
    data() {
      return {
        name: '',//名字
        pwd: '', // 密码
      }
    },
    methods: {
      loginsub() {
        let params = {
          name: this.name,
          pwd: this.pwd
        }
        if (this.name != '' && this.pwd != '') {
          this.$axios.post('/api/home/login', params, {}).then(res => {
            if (res.data.code == 200) {
              localStorage.setItem('token', res.data.data.token)
              localStorage.setItem('name', res.data.data.username)
              this.$router.push({name: 'index'})
            }
            console.log(res);
          }).catch(err => {
            console.log(err);
          })
        } else {
          this.$toast.fail('账号或密码错误');
        }
      }
    }
  }
</script>
<style scoped lang="scss">
  .login {
    width: 100%;
    height: 100%;
    position: fixed;
    background-image: url(../../../../static/img/bgc.jpeg);
    background-size: 100% 100%;
    background-repeat: no-repeat;
  }

  /*登录*/
  .login_tit {
    width: 100%;
    text-align: center;
    margin-top: 13.75rem;

    span {
      color: #fff;
      font-size: 3.125rem;
    }
  }

  /*登录提交*/
  .login_sub {
    width: 100%;

    form {
      /*账号*/
      .sub_item {
        width: 90%;
        height: 3rem;
        margin: 5rem auto;
        border-bottom: 1px solid #fff;
        text-align: center;

        input {
          border: none;
          outline: none;
          background: none;
          color: #fff;
          height: 2rem;
          font-size: 1.875rem;
          margin-bottom: 1rem;
          text-align: center;

          &:-webkit-autofill {
            -webkit-text-fill-color: #fff !important;
            transition: background-color 5000s ease-in-out 0s;
            font-size: 1.875rem !important;
            /*-webkit-box-shadow: 0 0 0 1000px inset !important;*/
          }

          &:focus {
            outline: none;
          }

          &::-webkit-input-placeholder {
            font-size: 1.875rem;
            color: #fff;
            text-align: center;
          }
        }
      }
    }
  }

  /*立即登录*/
  .submit {
    width: 100%;
    text-align: center;

    input, button {
      width: 90%;
      height: 4rem;
      background-color: #000000;
      color: #fff;
      font-size: 1.875rem;
      border: none;
      outline: none;
    }
  }
</style>
