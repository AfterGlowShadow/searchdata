import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    //默认首页
    {
      path: '/',
      redirect: '/index',
      meta: {requiresAuth: true},
    },
    //  首页跳转
    {
      path: '/index',
      component: () => import('@/components/view/index/index.vue/'),
      meta: {requiresAuth: true},
      name: 'index',
    },
    //登录
    {
      path: '/login',
      component: () => import('@/components/view/login/login.vue/'),
      name: 'login',
      meta: {type: 1}
    },
  ]
})
