<template>
  <div id="app">
    <navbar v-if="$route.meta.type != 1"></navbar>
    <router-view/>
  </div>
</template>
<script>
  import Navbar from "./components/view/navbar/navbar";

  export default {
    name: 'App',
    components: {Navbar}
  }
</script>
<style lang="scss">
  #app {
  }

  html, body {
    padding: 0;
    margin: 0;
  }

  body {
    /deep/ .el-container {
      width: 1200px;
      margin: 0 auto;
    }
  }
</style>
