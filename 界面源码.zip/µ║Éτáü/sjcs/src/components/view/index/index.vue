<template>
  <div class="index">
    <!--公告栏-->
    <el-container>
      <div class="index_announcement">
        <!--大标题-->
        <div class="announcement_h">
          <span>公告栏</span>
        </div>
        <!--内容-->
        <div class="announcement_con">
          <span>{{announcement.data}}</span>
        </div>
      </div>
    </el-container>
    <!--表格-->
    <el-container>
      <!--表格展示区-->
      <div class="table" v-if="type == 1">
        <!--搜索框-->
        <div class="table_seach">
          <input type="text" placeholder="请输入条形码/网店名称/厂家货号/供应商进行搜索" v-model="sea">
          <span @click="addseache" style="cursor: pointer">搜索</span>
        </div>
        <!--批量导出-->
        <div class="batchExport">
          <el-button type="primary" @click="pingDonwnloader">批量导出</el-button>
        </div>
        <!--表格显示-->
        <div class="table_content">
          <table width="95%" border="0" cellspacing="0" class="table_header" id="multipleTable">
            <!--表头-->
            <tr>
              <th style="width: 3%;height: 3%">
                <input type="checkbox" v-model="checkAll">
                <!--<el-checkbox v-model="checkAll">-->
                <!--</el-checkbox>-->
              </th>
              <th>产品图片</th>
              <th width="7%">条形码</th>
              <th width="7%">网店名称</th>
              <th width="9%">厂家货号</th>
              <th width="10%">供应商</th>
              <th width="11%">客诉问题点</th>
              <th width="12%">问题点分析</th>
              <th width="12%">问题点处理方案</th>
              <th width="8%">最后问题批次到货日期</th>
              <th width="8%">客诉首次反馈日期</th>
              <th width="10%">客户ID</th>
              <th width="6%">操作</th>
            </tr>
            <!--表格内容-->
            <tr v-for="(item,index) in list" :key="index" style="height: 80px">
              <td>
                <input type="checkbox" v-model="pick" :value="item.id">
                <!--<el-checkbox @change="addInPick(item,index)" :key="index" :value="item.id"></el-checkbox>-->
              </td>
              <td>
                <img :src="$url+item.goods_pic" alt="">
              </td>
              <td>
                <span>{{item.bar_code}}</span>
              </td>
              <td>
                <span>{{item.shop_name}}</span>
              </td>
              <td>
                <span>{{item.goods_number}}</span>
              </td>
              <td>
                <span>{{item.supplier}}</span>
              </td>
              <td>
                <span>{{item.question}}</span>
              </td>
              <td>
                <span>{{item.question_analysis}}</span>
              </td>
              <td>
                <span>{{item.question_solutions}}</span>
              </td>
              <td>
                <span>{{item.arrival_date}}</span>
              </td>
              <td>
                <span>{{item.feedback_date}}</span>
              </td>
              <td>
                <span>{{item.customer_id}}</span>
              </td>
              <td>
                <span style="cursor: pointer" @click="godetails(item)">详细</span>
              </td>
            </tr>
          </table>
        </div>
        <!--分页器-->
        <div class="table_pager">
          <el-pagination
            background
            :pager-count="7"
            @prev-click="previousPage"
            @next-click="nextClick"
            @current-change="handleCurrentPageChange"
            layout="prev, pager, next"
            :total="pages*10">
          </el-pagination>
        </div>
      </div>
      <!--详情-->
      <div class="table_details" v-if="type == 2">
        <!--返回按钮-->
        <div class="table_back">
          <span @click="type = 1"> <img src="../../../../static/img/back.png" alt=""> 返回</span>
        </div>
        <!--反馈问题详情-->
        <div class="table_feedback">
          <!--详情图片-->
          <div class="feedback_img">
            <viewer>
              <img :src="$url+details.goods_pic" alt="">
            </viewer>
          </div>
          <!--右侧详情-->
          <div class="feedback_right">
            <!--标题-->
            <div class="right_h">
              <span>反馈问题详情</span>
            </div>
            <!--下方数据-->
            <div class="right_down">
              <div class="down_left">
                <span>条形码:&nbsp;&nbsp;{{details.bar_code}}</span>
                <span>网店名称:&nbsp;&nbsp;{{details.shop_name}}</span>
                <span>厂家货号:&nbsp;&nbsp;{{details.goods_number}}</span>
                <span>供应商:&nbsp;&nbsp;{{details.supplier}}</span>
              </div>
              <!--数据右侧-->
              <div class="down_right">
                <span>最后问题批次到货日期:&nbsp;&nbsp;{{details.arrival_date}}</span>
                <span>客诉首次反馈日期:&nbsp;&nbsp;{{details.feedback_date}}</span>
                <span>客户ID(多个排序按反馈时间由早及晚):</span>
                <span>{{details.customer_id}}</span>
              </div>
            </div>
          </div>
        </div>
        <!--客诉问题点一系列问题-->
        <div class="trouble_spots">
          <!--客诉问题点-->
          <div class="spots_1">
            <span style="font-size: 16px;color: #333333">客诉问题点</span>
            <!--问题描述-->
            <div class="spots_1_con">
              <span>{{details.question}}</span>
            </div>
          </div>
          <!--问题点分析-->
          <div class="spots_1">
            <span style="font-size: 16px;color: #333333">问题点分析</span>
            <!--问题描述-->
            <div class="spots_1_con">
              <span>{{details.question_analysis}}</span>
            </div>
          </div>
          <!--问题点处理方案-->
          <div class="spots_1">
            <span style="font-size: 16px;color: #333333">问题点处理方案</span>
            <!--问题描述-->
            <div class="spots_1_con">
              <span>{{details.question_solutions}}</span>
            </div>
          </div>
        </div>
        <!--问题图片-->
        <div class="problem_pictures">
          <!--标题-->
          <div class="problem_tit">
            <span>问题图片</span>
          </div>
          <!--问题图片-->
          <div class="problem_img">
            <viewer>
              <img :src="$url+details.question_pic1" alt="">
              <img :src="$url+details.question_pic2" alt="">
              <img :src="$url+details.question_pic3" alt="">
              <img :src="$url+details.question_pic4" alt="">
            </viewer>
          </div>
        </div>
        <!--详情视频-->
        <div class="details_mp4">
          <div class="details_tit">
            <span>详情视频</span>
          </div>
          <div class="details_kuang">
            <span v-if="details.video == ''">暂无视频</span>
            <video width="100%" height="100%" controls :src="$url+details.video" v-if="details.video != ''">
              <!--<source :src="$url+details.video">-->
            </video>
          </div>
        </div>
        <!--备注-->
        <div class="note">
          <!--标题-->
          <div class="note_tit">
            <span>备注</span>
          </div>
          <!--备注框-->
          <div class="note_kuang">
            <span
              style="font-size: 20px;margin-top: 10px"
              v-if="details.remark1 == null && details.remark2 == null && details.remark3 == null && details.remark4 == null">暂无备注</span>
            <span>{{details.remark1}}</span>
            <span>{{details.remark2}}</span>
            <span>{{details.remark3}}</span>
            <span>{{details.remark4}}</span>
          </div>
        </div>
      </div>
    </el-container>
    <footerr></footerr>
  </div>
</template>
<script>
    import Footerr from "../footerr/footerr";
    import XLSX from 'xlsx'

    export default {
        name: "home",
        components: {Footerr},
        data() {
            return {
                type: 1, // 表格和详情切换
                list: [], // 数据列表接收
                details: [], //商品详情数据接收
                announcement: [], //公告栏数据接收
                sea: '', // 搜索框
                pages: '', // 分页器数据计算
                page: 1, // 分页器
                checkAll: false, //全选按钮
                diro: false, //单选按钮
                pick: [], // 内容数据
                // cities: cityOptions,
            }
        },
        created() {
            this.getlist()
            this.bullentBoard()
        },
        watch: {
            sea(val, oldval) {
                if (val == '') {
                    this.getlist()
                }
            },
            pick(val, oldval) {
            },
            checkAll(val, oldval) {
                if (val == true) {
                    let array = []
                    this.list.forEach(item => {
                        array.push(item.id)
                    })
                    this.pick = array
                    this.checkAll = true
                    console.log(this.pick);
                } else if (val == false) {
                    this.pick = []
                    this.checkAll = false
                    console.log(this.pick);
                }
            },
            page(val, oldval) {
                if (val != oldval) {
                    this.checkAll = false
                }
                // this.checkBoxAll(val, oldval)
            }
        },
        methods: {
            //数据列表
            getlist() {
                let params = {
                    page: this.page,
                    list_rows: 8,
                }
                this.$axios.post('/api/admin/data/datagetalllist', this.$qs.stringify(params), {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                }).then(res => {
                    this.list = res.data.data.data
                    this.pages = Math.ceil(res.data.data.total / res.data.data.listRows)
                    console.log(this.pages);
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },
            //前往详情
            godetails(item) {
                this.type = 2
                let params = {
                    id: item.id
                }
                this.$axios.post('/api/home/data/datagetone', params, {}).then(res => {
                    this.details = res.data.data
                    console.log(this.details);
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },
            //搜索
            addseache() {
                let params = {
                    page: this.page,
                    list_rows: 8,
                    search: this.sea,
                }
                this.$axios.post('/api/home/data/datalistlike', params, {}).then(res => {
                    this.list = res.data.data.data
                    this.pages = Math.ceil(res.data.data.total / res.data.data.listRows)
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },
            //公告栏数据
            bullentBoard() {
                let params = {}
                this.$axios.post('/api/home/daohang', {}, {}).then(res => {
                    this.announcement = res.data
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },
            //全选事件
            // checkBoxAll(val, oldval) {
            //   console.log(val);
            //   console.log(oldval);
            //   if (this.checkAll == false) {
            //     this.list.forEach(item => {
            //       this.pick.push(item.id)
            //     })
            //     this.checkAll = true
            //     console.log(this.pick);
            //   } else if (this.checkAll == true && oldval == undefined) {
            //     this.pick = []
            //     this.checkAll = false
            //     console.log(this.pick);
            //   } else if (this.checkAll == true && val != oldval) {
            //     this.checkAll = false
            //   }
            // },
            //批量导出
            // export2Excel() {
            //   require.ensure([], () => {
            //     const {export_json_to_excel} = require('../../../assets/excel/Export2Excel');
            //     const tHeader = ['序号', '帐号', '院校'];
            //     // 上面设置Excel的表格第一行的标题
            //     const filterVal = ['index', 'phone_Num', 'school_Name'];
            //     // 上面的index、phone_Num、school_Name是tableData里对象的属性
            //     const list = this.tableData;  //把data里的tableData存到list
            //     const data = this.formatJson(filterVal, list);
            //     export_json_to_excel(tHeader, data, '列表excel');
            //   })
            // },
            // formatJson(filterVal, jsonData) {
            //   return jsonData.map(v => filterVal.map(j => v[j]))
            // },
            barchExport() {
                let params = {
                    datalist: this.pick.join(',')
                }
                this.$axios.post('/api/bulkdata', this.$qs.stringify(params)).then(res => {
                    let data = res.data.data
                    this.pingDonwnloader(data)
                    console.log(res);
                }).catch(err => {
                    console.log(err);
                })
            },
            //拼接连接串下载文件
            pingDonwnloader() {
                // let url = window.URL.createObjectURL(res.data)
                let link = document.createElement('a')
                let params = {
                    datalist: this.pick.join(',')
                }
                link.style.display = 'none'
                link.href = this.$url + "/api/bulkdata?datalist=" + this.pick.join(",")
                link.setAttribute('download', '文件名称' + new Date().getTime() + '.xls')
                document.body.appendChild(link)
                link.click()
                this.$message({
                    message: '导出成功',
                    type: 'success'
                })
            },
            //导出表格
            //分页器
            //点击上一页
            previousPage() {
                this.page--
                this.getlist()
            },
            //点击下一页
            nextClick() {
                this.page++
                this.getlist()
            },
            //当点击分页器页数的时候
            handleCurrentPageChange(val) {
                this.page = val
                this.getlist()
            }
        }
    }
</script>
<style scoped lang="scss">
  .index {
    width: 100%;
    background-image: url("../../../../static/img/bgc.jpeg");
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }

  /*公告栏*/
  .index_announcement {
    width: 1200px;
    height: 160px;
    /*公告栏大标题*/
    .announcement_h {
      text-align: center;
      margin-top: 20px;

      span {
        font-size: 30px;
        color: #fff;
      }
    }

    /*内容*/
    .announcement_con {
      width: 100%;
      height: 60px;
      padding-top: 30px;
      text-indent: 30px;
      overflow-y: scroll;

      span {
        color: #fff;
      }
    }
  }

  /*表格*/
  .table {
    width: 1200px;
    height: 600px;
    background-color: #fff;
    display: flex;
    flex-direction: column;

    /*搜索*/
    .table_seach {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-top: 20px;

      input {
        width: 600px;
        height: 60px;
        border: none;
        outline: none;
        background-color: #F0F2F4;

        &::-webkit-input-placeholder {
          padding-left: 20px;
        }
      }

      span {
        display: inline-block;
        width: 200px;
        height: 60px;
        background-color: #08213A;
        font-size: 20px;
        color: #ffffff;
        text-align: center;
        line-height: 60px;
      }
    }

    /*批量导出按钮*/
    .batchExport {
      width: 95%;
      margin: 0 auto;
    }

    /*表格*/
    .table_content {
      text-align: center;
      height: 430px;
      overflow: scroll;

      table {
        margin: 10px auto;
        border-spacing: 0;
        border-collapse: collapse;

        tr {
          height: 80px;
          overflow: hidden;
          text-overflow: ellipsis;

        }

        th {
          height: 80px;
          background-color: #000000;
          color: #ffffff;
          font-size: 14px;
        }

        td {
          border: 1px solid #cccccc;
          height: 80px !important;
          word-break: break-all;

          span {
            color: #333333;
            font-size: 14px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 4;
            -webkit-box-orient: vertical;
          }

          img {
            width: 60px;
            height: 60px;
            margin: 10px 10px 10px 10px;
          }
        }

        .table_header {
          width: 100%;

        }
      }
    }

    /*分页器*/
    .table_pager {
      width: 100%;
      text-align: center;
      margin-top: 10px;
    }
  }

  /*商品详情*/
  .table_details {
    width: 1200px;
    height: 600px;
    overflow: scroll;
    background-color: #fff;
    flex-direction: column;
    /*返回按钮*/
    .table_back {
      width: 100%;
      margin-top: 20px;
      position: fixed;

      span {
        display: inline-block;
        width: 90px;
        height: 40px;
        background-color: #000000;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        cursor: pointer;

        img {
          width: 16px;
          height: 16px;
          margin-right: 10px;
        }
      }
    }

    /*反馈问题详情*/
    .table_feedback {
      width: 95%;
      margin: 0 auto;
      margin-top: 80px;
      display: flex;
      /*图片详情*/
      .feedback_img {
        img {
          width: 200px;
          height: 200px;
        }
      }

      /*右侧数据*/
      .feedback_right {
        width: 100%;
        display: flex;
        flex-direction: column;
        margin-left: 50px;
        /*标题*/
        .right_h {
          span {
            font-size: 30px;
            color: #333333;
          }
        }

        /*下方数据*/
        .right_down {
          width: 100%;
          display: flex;
          margin-top: 20px;
          /*下左数据*/
          .down_left {
            width: 100%;
            display: flex;
            flex-direction: column;

            span {
              margin-bottom: 10px;
            }
          }

          /*下右数据*/
          .down_right {
            width: 100%;
            display: flex;
            flex-direction: column;

            span {
              margin-bottom: 10px;
            }
          }
        }
      }
    }

    /*客诉问题这一系列*/
    .trouble_spots {
      width: 95%;
      margin: 30px auto;
      display: flex;
      justify-content: space-between;

      .spots_1 {
        width: 30%;
        display: flex;
        flex-direction: column;
        /*问题描述*/
        .spots_1_con {
          width: 100%;
          height: 160px;
          background-color: #DDDDDD;
          border: 1px solid rgba(221, 221, 221, 1);
          margin-top: 10px;
          overflow: scroll;

          span {
            font-size: 14px;
            color: #333333;
            margin-left: 20px;
            margin-top: 20px;
          }
        }
      }
    }

    /*问题图片*/
    .problem_pictures {
      width: 95%;
      margin: 20px auto;
      display: flex;
      flex-direction: column;
      /*标题*/
      .problem_tit {
        span {
          font-size: 16px;
          color: #333333;
        }
      }

      /*图片*/
      .problem_img {
        width: 100%;
        display: flex;
        margin-top: 20px;

        img {
          width: 180px;
          height: 180px;
          margin-right: 20px;
        }
      }
    }

    /*详情视频*/
    .details_mp4 {
      width: 95%;
      margin: 10px auto;

      .details_tit {
        span {
          font-size: 16px;
          color: #333333;
        }
      }

      /*视频框*/
      .details_kuang {
        width: 40%;
        height: 150px;
        background-color: #F4F4F4;
        margin-top: 10px;
      }
    }

    /*备注*/
    .note {
      width: 95%;
      margin: 10px auto;
      /*标题*/
      .note_tit {
        span {
          font-size: 16px;
          color: #333333;
        }
      }

      /*备注框*/
      .note_kuang {
        width: 100%;
        height: 100px;
        background-color: #F4F4F4;
        margin-top: 10px;
        display: flex;
        flex-direction: column;
        overflow: scroll;

        span {
          margin-left: 1rem;
        }
      }
    }
  }
</style>
