<template>
  <div class="footerr">
    <span>Copyright ©2019 浙ICP备123456789号-1 浙公网安备</span>
  </div>
</template>
<script>
  export default {
    name: "footerr"
  }
</script>
<style scoped lang="scss">
  .footerr {
    width: 1200px;
    height: 110px;
    line-height: 110px;
    text-align: center;
    margin: 0 auto;

    span {
      color: #fff;
    }
  }
</style>
