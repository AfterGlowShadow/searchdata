<template>
  <div class = "navbar">
    <div class = "navbar_con">
      <!--左侧网站信心-->
      <div class = "con_left">
        <span><img src = "../../../../static/img/seach_icon.png" alt = "">家具数据查询网站</span>
      </div>
      <!--右侧内容-->
      <div class = "con_right">
        <span>{{name}}</span>
        <span @click = "logout" style = "cursor: pointer"> <img src = "../../../../static/img/exit.png"
          alt = "">退出登录</span>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: "navbar",
    data() {
      return {
        name: localStorage.getItem('name')
      }
    },
    methods: {
      logout() {
        localStorage.removeItem('token')
        this.$router.push({name: 'login'})
      }
    }
  }
</script>
<style scoped lang = "scss">
  .navbar {
    width: 100%;
    height: 100px;
    background-color: #000000;
    /*版心*/
    .navbar_con {
      width: 1200px;
      height: 100px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      /*左侧内容*/
      .con_left {
        width: 100%;
        display: flex;
        justify-content: flex-start;
        
        span {
          font-size: 30px;
          color: #fff;
          display: flex;
          align-items: center;
          
          img {
            width: 36px;
            height: 36px;
            margin-right: 10px;
          }
        }
      }
      
      /*右侧内容*/
      .con_right {
        width: 100%;
        display: flex;
        justify-content: flex-end;
        
        span {
          font-size: 16px;
          color: #fff;
          display: flex;
          align-items: center;
          
          &:nth-child(1) {
            padding-right: 10px;
            height: 20px;
            display: inline-block;
            border-right: 1px solid #fff;
            line-height: 20px;
          }
          
          &:nth-child(2) {
            margin-left: 10px;
            
            img {
              width: 22px;
              height: 22px;
              margin-right: 10px;
            }
          }
        }
      }
    }
  }
</style>
