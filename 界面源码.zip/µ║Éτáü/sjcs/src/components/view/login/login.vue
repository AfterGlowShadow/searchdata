<template>
  <div class="login">
    <!--登录中心-->
    <div class="login_content">
      <!--登录-->
      <div class="content_login">
        <span>登录</span>
      </div>
      <!--登录框-->
      <div class="logsub">
        <form action="">
          <!--账号-->
          <div class="logsub_item">
            <input type="text" placeholder="请输入登录账号" v-model="name">
          </div>
          <!--密码-->
          <div class="logsub_item">
            <input type="password" placeholder="请输入登录密码" v-model="pwd">
          </div>
        </form>
      </div>
      <!--登录按钮-->
      <div class="sub" @click="loginsub">
        <input type="button" value="立即登录">
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: "login",
    data() {
      return {
        name: '',//名字
        pwd: '', // 密码
      }
    },
    created() {
    },
    methods: {
      loginsub() {
        let params = {
          name: this.name,
          pwd: this.pwd
        }
        if (this.name != '' && this.pwd != '') {
          this.$axios.post('/api/home/login', params, {}).then(res => {
            if (res.data.code == 200) {
              localStorage.setItem('token', res.data.data.token)
              localStorage.setItem('name', res.data.data.username)
              this.$router.push({name: 'index'})
            }
            console.log(res);
          }).catch(err => {
            console.log(err);
          })
        } else {
          this.$message.error('账号或密码错误')
        }
      }
    }
  }
</script>
<style scoped lang="scss">
  .login {
    width: 100%;
    height: 100%;
    position: fixed;
    background-image: url("../../../../static/img/bgc.jpeg");
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }

  /*登录大包围*/
  .login_content {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: fixed;
    top: 20%;
    /*登录文字*/
    .content_login {
      span {
        font-size: 40px;
        color: #fff;
      }
    }

    /*登录框*/
    .logsub {
      margin-top: 50px;

      form {
        .logsub_item {
          width: 400px;
          border-bottom: 1px solid #ffffff;
          text-align: center;
          margin-top: 50px;

          input {
            border: none;
            background: none;
            height: 50px;
            width: 150px;
            color: #fff;
            font-size: 20px;
            outline: none;
            text-align: center;
            &:-webkit-autofill{
              -webkit-text-fill-color: #fff !important;
              transition: background-color 5000s ease-in-out 0s;
            }
            &::-webkit-input-placeholder {
              color: #fff;
              font-size: 20px;
            }
          }
        }
      }
    }

    /*登录按钮*/
    .sub {
      margin-top: 50px;

      input, button {
        border: none;
        width: 400px;
        height: 50px;
        background: rgba(0, 0, 0, 1);
        color: #fff;
        font-size: 20px;
        outline: none;
      }
    }
  }
</style>
