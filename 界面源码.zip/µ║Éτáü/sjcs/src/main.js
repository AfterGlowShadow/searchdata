// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
//完整引入element
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

Vue.use(ElementUI);
//引入axios
import axios from 'axios'
import qs from 'qs'
//引入图片预览
import Viewer from 'v-viewer'
import 'viewerjs/dist/viewer.css'
//引入表格导出
import Blob from './assets/excel/Blog'
import Export2Excel from './assets/excel/Export2Excel'

Vue.use(Viewer)
//
axios.defaults.baseURL = process.env.BASEURL
Vue.prototype.$url = 'http://www.norhoraftersales.com'
//挂载axios
Vue.prototype.$axios = axios
Vue.prototype.$qs = qs
//axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'; // 全局请求头

Vue.config.productionTip = false
//导航守卫
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requiresAuth)) {
    //这里判断用户是否登录，验证本地存储是否有token
    if (!localStorage.getItem('token')) { // 判断当前的token是否存在
      next({
        path: '/login',
        query: {redirect: to.fullPath}
      })
    } else {
      next()
    }
  } else {
    next() // 确保一定要调用 next()
  }

})
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: {App},
  template: '<App/>'
})
