'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASEURL: '"http://www.norhoraftersales.com"',
}
